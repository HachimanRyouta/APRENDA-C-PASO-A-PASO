/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>
using namespace std;

int main()
{
    float costo = 15.00;                //El costo de un artículo 
    float impuesto_ventas = 0.06;       // El impuesto sobre ventas es 6 por ciento
    float cantidad_pagada = 20.00;      // La cantidad de que pagó el comprador
    float impuesto, cambio, total; // impuesto sobre venta. Cambio para 
                                        // el comprador y total de la factura
                                        
    impuesto = costo*impuesto_ventas;
    total = costo + impuesto; 
    cambio = cantidad_pagada - total;
    
    cout << "Costo del articulo: $" << costo << "\tImpuesto: $" << impuesto <<
    "\t total: $" << total << endl;
    cout << "Cambio para el cliente: $"<< cambio << endl;
    return 0;
}