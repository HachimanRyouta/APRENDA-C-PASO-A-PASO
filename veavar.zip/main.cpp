/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>
using namespace std;

int main()
{
    int edad = 32;
    float salario = 25000.75;
    long distancia_a_la_luna = 238857;
    
    cout << "El empleado tiene " << edad << " años"<< endl;
    cout << "El empleado gana " << salario << endl;
    cout << "La luna esta a unas " << distancia_a_la_luna << " millas de la tierra" << endl;
    return 0;
}